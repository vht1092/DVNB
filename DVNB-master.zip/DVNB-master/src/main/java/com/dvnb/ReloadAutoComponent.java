package com.dvnb;

/**
 * Load lai noi dung cho component thuong dung cho viec load noi dung tu dong
 * */
public interface ReloadAutoComponent {
	void eventReloadAuto();
}
