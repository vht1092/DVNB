package com.dvnb;

/**
 * Load lai noi dung cho component thuong dung cho viec load noi dung khi user
 * click vao tab dang mo
 */
public interface ReloadComponent {
	void eventReload();
}
